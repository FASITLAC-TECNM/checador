// services/index.js
// Punto de entrada centralizado para todos los servicios

// Servicios de usuarios
export {
    getUsuarios,
    getUsuario,
    crearUsuario,
    actualizarUsuario,
    eliminarUsuario,
    actualizarEstadoConexion,
    filtrarUsuarios,
    getEstadisticas
} from './api';

// Servicio modular de empleados
export { default as empleadoService } from './empleadoService';

// También exportar funciones individuales de empleados para facilitar su uso
export {
    getEmpleados,
    getEmpleado,
    getEmpleadoPorUsuario,
    crearEmpleado,
    actualizarEmpleado,
    eliminarEmpleado,
    validarPinEmpleado,
    buscarPorNSS,
    buscarPorRFC,
    getEmpleadosConUsuarios,
    validarNSSUnico,
    validarRFCUnico
} from './empleadoService';
